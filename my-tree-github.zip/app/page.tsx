import React from 'react'
import dynamic from 'next/dynamic'

const Graph = dynamic(() => import('@/components/Graph'), { ssr: false })

export default function Page() {
  return (
    <main className="max-w-6xl mx-auto p-4 space-y-3">
      <h1 className="text-2xl font-semibold">my tree</h1>
      <p className="text-slate-600">A visual graph of the people you've crossed paths with.</p>
      <Graph />
    </main>
  )
}
