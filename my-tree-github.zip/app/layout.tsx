import './globals.css'
import React from 'react'
export const metadata = { title: 'my tree', description: 'Your visual connection graph' }
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body className="min-h-screen">{children}</body></html>);
}
