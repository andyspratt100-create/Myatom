'use client'
import React, { useMemo, useRef, useState, useEffect } from 'react'
import ForceGraph2D from 'react-force-graph-2d'
import { QRCodeCanvas } from 'qrcode.react'

type Node = { id: string; name: string; group?: string; location?: string; metAt?: string; links?: { platform?: string; url: string }[]; x?: number; y?: number }
type Link = { source: any; target: any; type?: string; weight?: number; metAt?: string }

const seed = { nodes: [
  { id: 'you', name: 'You', group: 'root' },
  { id: 'a1', name: 'Alex Santos', group: 'Work', links: [{ platform: 'LinkedIn', url: 'https://linkedin.com/in/example'}], metAt: '2022-10-12', location: 'London' },
  { id: 'b2', name: 'Bea Chen', group: 'Uni', links: [{ platform: 'Instagram', url: 'https://instagram.com/example'}], metAt: '2018-05-04', location: 'Cambridge' },
  { id: 'c3', name: 'Carlos M.', group: 'Travel', links: [{ platform: 'Twitter', url: 'https://x.com/example'}], metAt: '2023-07-22', location: 'Ericeira' },
  { id: 'd4', name: 'Diana Park', group: 'Event', links: [{ platform: 'Website', url: 'https://example.com'}], metAt: '2024-03-11', location: 'Berlin' },
  { id: 'e5', name: 'Ethan R.', group: 'Family', links: [], metAt: '2010-04-01', location: 'Manchester' },
], links: [
  { source: 'you', target: 'a1', type: 'met_at', weight: 0.8, metAt: '2022-10-12' },
  { source: 'you', target: 'b2', type: 'classmate', weight: 0.7, metAt: '2018-05-04' },
  { source: 'you', target: 'c3', type: 'met_at', weight: 0.5, metAt: '2023-07-22' },
  { source: 'you', target: 'd4', type: 'event', weight: 0.6, metAt: '2024-03-11' },
  { source: 'you', target: 'e5', type: 'family_of', weight: 0.9, metAt: '2010-04-01' },
  { source: 'a1', target: 'd4', type: 'coworked', weight: 0.4, metAt: '2024-02-02' },
  { source: 'b2', target: 'a1', type: 'introduced_by', weight: 0.3, metAt: '2022-12-01' },
]}

const groupColor = (g?: string) => ({ root:'#111827',Work:'#2563eb',Uni:'#16a34a',Travel:'#f59e0b',Event:'#8b5cf6',Family:'#ef4444',Other:'#64748b' }[g||'Other']||'#64748b')
const niceDate = (iso?: string) => iso ? new Date(iso).toLocaleDateString() : '—'
const yearOf = (iso?: string) => iso ? new Date(iso).getFullYear() : undefined

export default function Graph() {
  const fgRef = useRef<any>(null)
  const [graph, setGraph] = useState(seed)
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<Node | null>(null)
  const [yearCutoff, setYearCutoff] = useState(2010)
  const [qrOpen, setQrOpen] = useState(false)
  const [showAdd, setShowAdd] = useState(false)
  const [newPerson, setNewPerson] = useState({ name: '', group: 'Other', when: '', where: '', linkUrl: '' })

  const minYear = useMemo(() => { const ys = graph.links.map(l=>yearOf(l.metAt)).filter(Boolean) as number[]; return ys.length?Math.min(...ys):2010 },[graph])
  const currentYear = new Date().getFullYear()
  const maxYear = useMemo(() => { const ys = graph.links.map(l=>yearOf(l.metAt)).filter(Boolean) as number[]; return ys.length?Math.max(...ys,currentYear):currentYear },[graph])

  const filtered = useMemo(() => {
    const activeLinks = graph.links.filter(l => (yearOf(l.metAt) || 1900) >= yearCutoff)
    const ids = new Set<string>(['you']); activeLinks.forEach(l => { ids.add(l.source as string); ids.add(l.target as string) })
    const nodes = graph.nodes.filter(n => ids.has(n.id)); return { nodes, links: activeLinks }
  }, [graph, yearCutoff])

  useEffect(()=>{ if(!selected||!fgRef.current) return; fgRef.current.centerAt(selected.x, selected.y, 600); fgRef.current.zoom(3,600) },[selected])

  const nodePaint = (node:any, ctx:CanvasRenderingContext2D, scale:number) => {
    const size = 6 + (node.id==='you'?6:0); ctx.beginPath(); ctx.arc(node.x,node.y,size,0,2*Math.PI)
    ctx.fillStyle = groupColor(node.group||(node.id==='you'?'root':'Other')); ctx.globalAlpha=0.9; ctx.fill(); ctx.globalAlpha=1
    const label = node.name||node.id; const fontSize = Math.max(10,12/Math.sqrt(scale)); ctx.font = `${fontSize}px ui-sans-serif, system-ui`
    ctx.fillStyle='#111827'; ctx.strokeStyle='#ffffff'; ctx.lineWidth=3/Math.sqrt(scale); ctx.strokeText(label,node.x+size+2,node.y+3); ctx.fillText(label,node.x+size+2,node.y+3)
  }
  const linkPaint = (link:any, ctx:CanvasRenderingContext2D) => { ctx.strokeStyle='rgba(2,6,23,0.15)'; ctx.lineWidth=Math.max(1,(link.weight||0.5)*2); ctx.beginPath(); ctx.moveTo(link.source.x,link.source.y); ctx.lineTo(link.target.x,link.target.y); ctx.stroke() }

  const addPerson = (e?:React.FormEvent) => { e?.preventDefault(); if(!newPerson.name.trim()) return
    const id=`n${Math.random().toString(36).slice(2,8)}`
    const node={ id, name:newPerson.name.trim(), group:newPerson.group, links:newPerson.linkUrl?[{platform:'Link',url:newPerson.linkUrl}]:[], metAt:newPerson.when, location:newPerson.where }
    const link={ source:'you', target:id, type:'met_at', weight:0.5, metAt:newPerson.when||new Date().toISOString().slice(0,10) }
    setGraph(g=>({ nodes:[...g.nodes, node], links:[...g.links, link] })); setShowAdd(false); setNewPerson({ name:'', group:'Other', when:'', where:'', linkUrl:'' })
  }

  const token = Buffer.from(JSON.stringify({ t: Math.floor(Date.now()/1000), uid: 'you', scope: ['name','links'] })).toString('base64')
  const searchFilter = (n:Node) => (search ? (n.name||'').toLowerCase().includes(search.toLowerCase()) : true)

  return (<div className="w-full h-full">
    <div className="sticky top-0 z-20 bg-white/80 backdrop-blur border-b border-slate-200">
      <div className="max-w-6xl mx-auto flex items-center gap-2 p-3">
        <div className="text-lg font-semibold tracking-tight">my tree · prototype</div>
        <div className="ml-auto flex items-center gap-2">
          <div className="relative flex items-center">
            <input value={search} onChange={(e)=>setSearch(e.target.value)} placeholder="Search people…" className="pl-8 pr-3 py-1.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-slate-400" />
            <span className="absolute left-2 text-slate-500 text-sm">🔎</span>
          </div>
          <button onClick={()=>setShowAdd(true)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 text-white text-sm hover:bg-slate-800">➕ Add person</button>
          <button onClick={()=>setQrOpen(true)} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 text-sm hover:bg-slate-50">🧾 Share QR</button>
        </div>
      </div>
    </div>

    <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-4 gap-3 p-3">
      <div className="lg:col-span-3 h-[72vh] rounded-xl border border-slate-200 overflow-hidden">
        <div className="h-10 flex items-center gap-2 px-3 border-b border-slate-200 text-sm font-medium">👥 Your graph</div>
        <div className="h-[calc(72vh-2.5rem)]">
          {/* @ts-ignore */}
          <ForceGraph2D ref={fgRef} graphData={{ nodes: filtered.nodes.map(n=>({...n})), links: filtered.links.map(l=>({...l})) }}
            nodeLabel={(n:any)=>`${n.name||n.id}\n${n.group||''}`} onNodeClick={(n:any)=>setSelected(n)}
            linkDirectionalParticles={1} linkDirectionalParticleWidth={(l:any)=>Math.max(1,(l.weight||0.5)*2)} linkDirectionalParticleSpeed={0.002}
            cooldownTicks={60} nodeCanvasObject={nodePaint} linkCanvasObject={linkPaint} enableNodeDrag d3VelocityDecay={0.3} />
        </div>
      </div>
      <div className="lg:col-span-1 h-[72vh] rounded-xl border border-slate-200 p-3 flex flex-col gap-4">
        <div><div className="text-xs text-slate-500">Show connections from year</div>
          <div className="flex items-center gap-3 mt-2"><input type="range" min={minYear} max={maxYear} step={1} value={yearCutoff} onChange={(e)=>setYearCutoff(parseInt(e.target.value))} className="w-full"/><span className="px-2 py-1 text-xs rounded bg-slate-100">{yearCutoff}</span></div>
        </div>
        <div className="border-t pt-3">
          <div className="text-xs uppercase tracking-wide text-slate-500 mb-2">Search results</div>
          <div className="space-y-2 overflow-auto max-h-[48vh] pr-1">
            {filtered.nodes.filter(searchFilter).map(n=>(
              <button key={n.id} onClick={()=>setSelected(n)} className={`w-full text-left px-2 py-1 rounded hover:bg-slate-50 border ${selected?.id===n.id?'border-slate-900':'border-slate-200'}`}>
                <div className="font-medium text-sm">{n.name}</div>
                <div className="text-xs text-slate-500 flex items-center gap-2"><span>{n.group|| (n.id==='you'?'root':'Other')}</span>·<span>{n.location||'—'}</span></div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>

    {selected && (<div className="fixed bottom-4 left-1/2 -translate-x-1/2 w-[92vw] max-w-3xl shadow-2xl border border-slate-200 rounded-2xl bg-white"><div className="flex items-start gap-3 p-3">
      <div className="flex-1"><div className="flex items-center gap-2"><div className="text-base font-semibold">{selected.name}</div></div>
        <div className="text-sm text-slate-600 mt-1">Met: {niceDate(selected.metAt)} in {selected.location || '—'}</div>
        <div className="mt-2 flex flex-wrap gap-2">{(selected.links||[]).map((l,i)=>(<a key={i} href={l.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg border border-slate-200 text-sm hover:bg-slate-50"><span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs bg-slate-100 text-slate-700">link</span><span className="truncate max-w-[12rem]">{l.url}</span></a>))}</div>
      </div><button onClick={()=>setSelected(null)} className="p-2 rounded-lg hover:bg-slate-100">✕</button></div></div>)}

    {showAdd && (<div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4"><div className="w-full max-w-lg bg-white rounded-2xl shadow-xl border border-slate-200">
      <div className="flex items-center justify-between p-3 border-b"><div className="font-semibold">Add a person</div><button onClick={()=>setShowAdd(false)} className="p-2 rounded hover:bg-slate-100">✕</button></div>
      <form onSubmit={addPerson} className="p-4 grid grid-cols-2 gap-3">
        <label className="col-span-2 text-sm">Name<input className="mt-1 w-full border rounded-lg p-2" value={newPerson.name} onChange={(e)=>setNewPerson(p=>({...p, name:e.target.value}))} placeholder="e.g., Jordan Lee" required/></label>
        <label className="text-sm">Group<select className="mt-1 w-full border rounded-lg p-2" value={newPerson.group} onChange={(e)=>setNewPerson(p=>({...p, group:e.target.value}))}><option>Work</option><option>Uni</option><option>Travel</option><option>Event</option><option>Family</option><option>Other</option></select></label>
        <label className="text-sm">When<input type="date" className="mt-1 w-full border rounded-lg p-2" value={newPerson.when} onChange={(e)=>setNewPerson(p=>({...p, when:e.target.value}))}/></label>
        <label className="col-span-2 text-sm">Where<input className="mt-1 w-full border rounded-lg p-2" value={newPerson.where} onChange={(e)=>setNewPerson(p=>({...p, where:e.target.value}))} placeholder="City / event"/></label>
        <label className="col-span-2 text-sm">Link (optional)<input className="mt-1 w-full border rounded-lg p-2" value={newPerson.linkUrl} onChange={(e)=>setNewPerson(p=>({...p, linkUrl:e.target.value}))} placeholder="https://…"/></label>
        <div className="col-span-2 flex justify-end gap-2 pt-1"><button type="button" onClick={()=>setShowAdd(false)} className="px-3 py-1.5 rounded-lg border">Cancel</button><button type="submit" className="px-3 py-1.5 rounded-lg bg-slate-900 text-white">Add</button></div>
      </form></div></div>)}

    {qrOpen && (<div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4"><div className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-slate-200 p-4">
      <div className="flex items-center justify-between mb-3"><div className="font-semibold">Share your connect QR</div><button onClick={()=>setQrOpen(false)} className="p-2 rounded hover:bg-slate-100">✕</button></div>
      <div className="flex flex-col items-center gap-3"><QRCodeCanvas value={`connect:${token}`} size={220} includeMargin /><div className="text-xs text-slate-600 break-all">Token: {token}</div></div>
    </div></div>)}
  </div>)
}
